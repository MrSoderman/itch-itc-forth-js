======================================================================
  TRUE ITC FORTH IN 256 LOC v 0.8
  by Jimmy Söderman | Uppsala, Sweden | October 2026
======================================================================

OVERVIEW
--------
This file contains a true Indirect Threaded Code (ITC) Forth engine and core 
written in a remarkably compact codebase (active parts JavaScript + Forth Core words = totally 256 LOC) + modules. 
Although modeled on a 16-bit architecture, the engine can be easily configured to support 64-bit cells over its flat memory bus.

THE FORTH-IN-NONFORTH TO FORTH-IN-FORTH JOURNEY
-----------------------------------------------
This system achieves a true "Forth-in-Forth" (metacircular) state through a 
precise bootstrap sequence where the outer interpreter is ultimately written 
in Forth words.

Boot sequence:

* Primitives: Defined in the underlying substrate (JavaScript, assembly, or hardware).
* Inner Interpret gets defined in the underaying substrate (JavaScript, Asm or Hardware etc). This is the well-konwn "NEXT" loop, and traditionally it should never know of any compiling or interpretation modes. It just does its job blindly.
* Outer Interpreter gets defined in the underlying substrate, this is actually not called outer Interpreter yet, we call it a seed, bc it is temporary. We need it just for a brief moment.
* We read in Core Words using the seed. These are simply High-level words that are built from those primitives that we have.
* Once core words are loaded, we have enough words to express the outer interpreter as high-level Forth words and we discar the seed, we don't need it anymore. This is the last step.

We are now fully Forth-in-Forth, metacircular, and self-hosting.


1:1 ARCHITECTURE (EASY TO PORT TO ASSEMBLY OR BASIC)
----------------------------------------------------
Designed with a clean 1:1 structural layout mirroring low-level procedural code, 
making it exceptionally simple for JavaScript and web developers to understand, 
translate, or port directly into assembly, machine code, or BASIC environments.


THE VM
------
* The Primitives: These are the opcodes basically.
* The Inner Interpreter. This could be seen as a normal CPU bc classicly, as it does not even know about states, compiling and interpretation. It just executes primvitives blindly. It is often called NEXT but I call it STEP here.
* The Environment (just like any normal CPU): The underlying state where everything operates so it can actually do something, including:
SP ---> Data Stack
RP ---> Return Stack
IP ---> Instruction Pointer
W  ---> Working Register (ITC-Specific) Because we use Indirect Threaded Code (ITC) we also have a W register—something you are not as used to seeing in a standard CPU. It is required by ITC to track active word addresses for execution handlers like DOCOL and DOCREATE/DOES>, which is what makes ITC a bit unique.


PDP-11 ARCHITECTURAL KINSHIP
---------------------------
True to the spirit of classical minicomputers like the PDP-11, this engine uses 
a pristine Indirect Threaded Code (ITC) design, explicit hardware-style registers 
(IP, W, SP, RP), and a flat memory model to achieve clean, orthogonal execution 
both conceptually and in its software implementation.


KEY FEATURES
------------
* 35 Core Primitives (also exist in 26 primitives and a few more)
* True ITC Architecture: Implements core Forth primitives, control flow, 
  dictionary management, and an inner/outer interpreter.
* Graphical Screen: Features a 128x96 byte color screen (colors 0–15) mapped 
  at C000h, complete with hardware-level Bresenham line drawing and a 60 Hz 
  VBLANK loop.
* Interactive Development Environment: Includes a built-in text editor, a 
  live REPL console (OK> prompt), and execution controls (RUN, STOP, CLEAR).
* Visual Explorer: An optional "EXPLORE" tool that lets you inspect the 
  dictionary in real-time, step through execution, and monitor data and 
  return stacks.
* Inline JavaScript Integration: Includes optional host API hooks allowing JS[ ... ]JS 
  code execution.


HOW TO RUN
----------
1. Extract the files from your ZIP archive.
2. Double-click or open `itc-baremetal.html` in any modern web browser 
   (Chrome, Firefox, Safari, Edge).
3. No compilation, servers, or local installations are required!


USAGE & CONTROLS
----------------
* Editor: Modify or write your Forth programs directly in the text editor 
  area, then click **RUN** to execute.
* REPL Console: Type individual Forth commands directly into the prompt (`OK>`).
* Explorer: Click the **EXPLORE** button to open the interactive debugger/inspector 
  view, where you can step through code execution line by line.
* Shortcuts: Press `Ctrl + Enter` (or `Cmd + Enter`) to quickly run the program from the editor.